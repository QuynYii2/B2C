@extends('master')

@section('title', 'Tìm kiếm sản phẩm')

@section('content')
    <div class="container">
        <h1>Kết quả tìm kiếm</h1>
        <p>Text: {{ $text }}</p>
        <p>Dropdown value: {{ $dropdownValue }}</p>

        <div class="search-results">
            {!! $html !!}
        </div>
    </div>
@endsection
